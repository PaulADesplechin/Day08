new Splide( '.splide', {
    type   : 'loop',
    padding: '20%',
  } );